# Predicting-Cloud-Workload-Using-ANN

Some ML algos implemented on predicting server load based on history

To build:
Runs on Ubuntu systems with following apt packages and steps. Use pip for Python 2.7.

0. Run 'sudo apt install python-openssl librsync-dev build-essential libssl-dev libffi-dev python-dev libssl-dev unity-lens-photos gir1.2-signon-1.0 libsignon-glib1 adium-theme-ubuntu python-tk'
1. Run 'pip install -r requirements.txt'
2. Run 'python Final.py' to generate output and graphical images.